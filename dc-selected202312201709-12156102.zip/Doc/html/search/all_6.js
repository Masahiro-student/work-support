var searchData=
[
  ['number_5fof_5fmotor_0',['Number_of_motor',['../d6/da6/_m_i_r2-13_w_8ino.html#a219f544020989ca7f65ed103547fb2ad',1,'MIR2-13W.ino']]],
  ['number_5fof_5fvalves_1',['Number_of_valves',['../d6/da6/_m_i_r2-13_w_8ino.html#ab78925d9d2a97b401810fa500e4d79d0',1,'MIR2-13W.ino']]]
];
