var searchData=
[
  ['receive_5fbuff_5fclear_0',['Receive_Buff_Clear',['../d6/da6/_m_i_r2-13_w_8ino.html#a1ab2193bff521ccdc6ba1ca3cf7ea469',1,'MIR2-13W.ino']]]
];
