var searchData=
[
  ['presser_5fset_0',['Presser_Set',['../d6/da6/_m_i_r2-13_w_8ino.html#a62df72149b28c2196aeee9482ad69ad3',1,'MIR2-13W.ino']]]
];
