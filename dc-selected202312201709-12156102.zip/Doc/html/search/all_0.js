var searchData=
[
  ['befor_5fbit_5f0_0',['befor_bit_0',['../d6/da6/_m_i_r2-13_w_8ino.html#a4a64df0bddf74f5d6dc899644bebc4ba',1,'MIR2-13W.ino']]],
  ['befor_5fbit_5f1_1',['befor_bit_1',['../d6/da6/_m_i_r2-13_w_8ino.html#ab8d2b7ac44c15a839afae70a6bb47fcd',1,'MIR2-13W.ino']]]
];
