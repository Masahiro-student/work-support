var searchData=
[
  ['max_5fduty_0',['Max_Duty',['../d6/da6/_m_i_r2-13_w_8ino.html#aaf0aebe75b91ea417e32bb392e4b92f9',1,'MIR2-13W.ino']]],
  ['max_5fpresser_1',['Max_Presser',['../d6/da6/_m_i_r2-13_w_8ino.html#abb04eb8789f7d2e08c32531558b005e9',1,'MIR2-13W.ino']]],
  ['min_5fpresser_2',['Min_Presser',['../d6/da6/_m_i_r2-13_w_8ino.html#a788eef343275faf6488b4563baf35d8e',1,'MIR2-13W.ino']]],
  ['motor_5fnum_3',['motor_num',['../d6/da6/_m_i_r2-13_w_8ino.html#ac1da510a6193bdc158e20ea9c1e0772c',1,'MIR2-13W.ino']]],
  ['motor_5fperiod_4',['motor_period',['../d6/da6/_m_i_r2-13_w_8ino.html#a5421905bc98420b924c60b81aadcbaec',1,'MIR2-13W.ino']]],
  ['motor_5fstate_5',['motor_state',['../d6/da6/_m_i_r2-13_w_8ino.html#a38b64b41194bb3b825c0e099a83e06f3',1,'MIR2-13W.ino']]]
];
