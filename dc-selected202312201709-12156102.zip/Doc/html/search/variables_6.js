var searchData=
[
  ['send_5ftext_0',['send_text',['../d6/da6/_m_i_r2-13_w_8ino.html#a9615c08458ab8291fe50f83003e6b212',1,'MIR2-13W.ino']]]
];
