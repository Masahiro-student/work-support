var searchData=
[
  ['time_5fcount_0',['time_count',['../d6/da6/_m_i_r2-13_w_8ino.html#a9b292da4ef8c9dbf619bef0fecc3e8e0',1,'MIR2-13W.ino']]],
  ['timer_1',['timer',['../d6/da6/_m_i_r2-13_w_8ino.html#a3c3e683a005eace2dd1e4d551056d9b6',1,'MIR2-13W.ino']]]
];
