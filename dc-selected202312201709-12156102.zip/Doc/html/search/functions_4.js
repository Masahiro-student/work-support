var searchData=
[
  ['send_5fdata_0',['Send_Data',['../d6/da6/_m_i_r2-13_w_8ino.html#a35c72b373e6b2ab7f5d61a6f6938eb2d',1,'MIR2-13W.ino']]],
  ['serialcheck_1',['SerialCheck',['../d6/da6/_m_i_r2-13_w_8ino.html#adb1870b762a2eeacdb0775d87c4f5e5a',1,'MIR2-13W.ino']]],
  ['setup_2',['setup',['../d6/da6/_m_i_r2-13_w_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'MIR2-13W.ino']]],
  ['split_3',['split',['../d6/da6/_m_i_r2-13_w_8ino.html#a9a5edd31489afd1a59c213060b4c2844',1,'MIR2-13W.ino']]]
];
