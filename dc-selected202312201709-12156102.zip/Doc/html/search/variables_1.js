var searchData=
[
  ['comp_5freceive_5fbuff_0',['Comp_Receive_Buff',['../d6/da6/_m_i_r2-13_w_8ino.html#af9f830a131546fc9f159e0d4c14f5461',1,'MIR2-13W.ino']]],
  ['comp_5freceive_5fstr_1',['Comp_Receive_Str',['../d6/da6/_m_i_r2-13_w_8ino.html#ab492b68df8a616bbb0cc63661a3faa53',1,'MIR2-13W.ino']]]
];
