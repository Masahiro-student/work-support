var searchData=
[
  ['g_5fcmds_0',['g_cmds',['../d6/da6/_m_i_r2-13_w_8ino.html#a583d1082c0f7f32c3e00c98eb0fe9859',1,'MIR2-13W.ino']]],
  ['g_5fdata_1',['g_data',['../d6/da6/_m_i_r2-13_w_8ino.html#ad9d02b8e36ac49d465acd7a504e9f633',1,'MIR2-13W.ino']]]
];
