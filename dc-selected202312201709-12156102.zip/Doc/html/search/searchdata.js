var indexSectionsWithContent =
{
  0: "bceglmnoprstv",
  1: "m",
  2: "loprstv",
  3: "bcgmnpstv",
  4: "c",
  5: "emv"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "defines"
};

var indexSectionLabels =
{
  0: "全て",
  1: "ファイル",
  2: "関数",
  3: "変数",
  4: "列挙型",
  5: "マクロ定義"
};

