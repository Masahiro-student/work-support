var searchData=
[
  ['error1_0',['Error1',['../d6/da6/_m_i_r2-13_w_8ino.html#a6e1bb18d24aaabb735e6b7ceeccafb4b',1,'MIR2-13W.ino']]],
  ['error2_1',['Error2',['../d6/da6/_m_i_r2-13_w_8ino.html#a943a2370e24f1abadb23ddd678d94732',1,'MIR2-13W.ino']]]
];
